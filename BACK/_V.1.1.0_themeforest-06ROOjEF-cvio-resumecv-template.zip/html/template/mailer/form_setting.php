<?php
	/*Form settings*/
	$subj = "New message from the site 'Cvio - Resume/CV Template'"; //letter subject
	$to = 'beshleyua@gmail.com'; // Enter Your E-mail
	$from = 'admin@you-site-name.com'; // Admin e-mail
	$fromName = 'Your Company Name'; // Your company name
	$charset = 'UTF-8';
?>